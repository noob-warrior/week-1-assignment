// grabbed this shortcut because typing React.createElement everywhere gets annoying
const createEl = React.createElement;

// TODO maybe convert this whole thing to JSX later


// quick reusable section wrapper
// i almost made this with jsx first but keeping it simple for now
function CardSection(sectionProps) {
    return createEl(
        "section",
        { className: "section-card" },
        createEl("h2", null, sectionProps.title),
        sectionProps.children
    );
}


// basic profile details
function PersonalInfo() {

  let fullName = "Ritesh kumar";  // kept let here out of habit
  const jobRole = "Frontend Developer";
  const favouriteThing = "Designing responsive web pages";

// i was testing another hobby here before
// favouriteThing = "Watching movies";


  return createEl(
      CardSection,
      { title: "Task 1: Display Personal Info with JSX" },

      createEl("p", null, "Name: " + fullName),
      createEl("p", null, "Profession: " + jobRole),
      createEl("p", null, "Hobby: " + favouriteThing)
  );
}


function CurrentDateTime() {

    // using array indexing here because that's how i usually write useState in plain js
    const clockState = React.useState(new Date());
    const timeNow = clockState[0];
    const updateTime = clockState[1];

    React.useEffect(function () {

        const timerId = setInterval(function () {
            const latestDate = new Date();
            updateTime(latestDate);
        }, 1000);

        // cleanup
        return function () {
            clearInterval(timerId);
        };

    }, []);

    return createEl(
        CardSection,
        { title: "Task 2: Display Current Date & Time" },
        createEl("p", null, timeNow.toLocaleString())
    );
}



function GreetingMessage() {

    const languageState = React.useState("english");

    const currentLanguage = languageState[0];
    const setCurrentLanguage = languageState[1];

    let greetText = "Hello, World!";

    // maybe later add more languages here
    if (currentLanguage === "spanish") {
        greetText = "Hola, Mundo!";
    }

    function switchGreetingLanguage() {

        const nextLanguage =
            currentLanguage === "english" ? "spanish" : "english";

        setCurrentLanguage(nextLanguage);
    }

    return createEl(
        CardSection,
        { title: "Task 3: Dynamic Greeting Message" },

        createEl("p", null, greetText),

        createEl(
            "p",
            null,
            "Greeting changes based on the value of the language variable."
        ),

        createEl(
            "button",
            {
                onClick: switchGreetingLanguage
            },
            "Switch Language"
        )
    );
}



function StoryTable() {

    // sample stories list
    const storyRows = [
        {
            title: "React Basics",
            url: "https://react.dev",
            author: "Ritesh kumar",
            num_comments: 18,
            points: 92,
            objectID: "101"
        },

        {
            title: "Learning JSX",
            url: "https://react.dev/learn/writing-markup-with-jsx",
            author: "Pranjal",
            num_comments: 12,
            points: 76,
            objectID: "102"
        },

        {
            title: "Component Props Guide",
            url: "https://react.dev/learn/passing-props-to-a-component",
            author: "Amar",
            num_comments: 9,
            points: 61,
            objectID: "103"
        }
    ];


    const rows = storyRows.map(function(storyItem) {

        // keeping this verbose on purpose so it stays easy to read
        return createEl(
            "tr",
            { key: storyItem.objectID },

            createEl("td", null, storyItem.title),

            createEl(
                "td",
                null,

                createEl(
                    "a",
                    {
                        href: storyItem.url,
                        target: "_blank",
                        rel: "noreferrer"
                    },
                    storyItem.url
                )
            ),

            createEl("td", null, storyItem.author),
            createEl("td", null, String(storyItem.num_comments)),
            createEl("td", null, String(storyItem.points)),
            createEl("td", null, storyItem.objectID)
        );

    });

    return createEl(
        CardSection,
        { title: "Task 4: Display List Using map() in JSX" },

        createEl(
            "table",
            null,

            createEl(
                "thead",
                null,

                createEl(
                    "tr",
                    null,
                    createEl("th", null, "Title"),
                    createEl("th", null, "URL"),
                    createEl("th", null, "Author"),
                    createEl("th", null, "Comments"),
                    createEl("th", null, "Points"),
                    createEl("th", null, "Object ID")
                )
            ),

            createEl(
                "tbody",
                null,
                rows
            )
        )
    );
}



function UserCard(userProps) {

    return createEl(
        "div",
        { className: "user-card" },

        createEl("h3", null, userProps.name),

        createEl("p", null, "Age: " + userProps.age),

        createEl("p", null, "Email: " + userProps.email)
    );
}



function UserCardSection() {

    const usersList = [
        {
            id: 1,
            name: "Ritesh kumar",
            age: 22,
            email: "ritesh.kumar@example.com"
        }
    ];

    return createEl(
        CardSection,
        { title: "Task 5: User Card Component with Props" },

        createEl(
            "div",
            { className: "user-card-list" },

            usersList.map(function(singleUser) {

                return createEl(UserCard, {
                    key: singleUser.id,
                    name: singleUser.name,
                    age: singleUser.age,
                    email: singleUser.email
                });

            })
        )
    );
}



function ProductList(componentProps) {

    const allProducts = componentProps.products;

    return createEl(
        "ul",
        { className: "product-list" },

        allProducts.map(function(item) {

            const priceText = "$" + item.price;

            return createEl(
                "li",
                { key: item.id },

                createEl("span", null, item.name),
                createEl("strong", null, priceText)
            );

        })
    );
}



function ProductSection() {

    // product prices are fake sample data obviously
    const productsData = [
        { id: 1, name: "Keyboard", price: 45 },
        { id: 2, name: "Mouse", price: 25 },
        { id: 3, name: "Monitor", price: 180 }
    ];

    return createEl(
        CardSection,
        { title: "Task 6: Product List with Parent-Child Components" },

        createEl(
            "p",
            null,
            "The parent component sends the products array to the child component."
        ),

        createEl(ProductList, {
            products: productsData
        })
    );
}



// main app
function App() {

    return createEl(
        "main",
        { className: "app" },

        createEl(
            "header",
            { className: "page-header" },

            createEl("p", null, "React Based Coding Assignment"),

            createEl("h1", null, "Assignment 1")
        ),

        createEl(
            "div",
            { className: "task-grid" },

            createEl(PersonalInfo),
            createEl(CurrentDateTime),
            createEl(GreetingMessage),
            createEl(StoryTable),
            createEl(UserCardSection),
            createEl(ProductSection)
        )
    );
}


const rootElement = document.getElementById("root");
const rootApp = ReactDOM.createRoot(rootElement);

rootApp.render(createEl(App));


/*
Random note to self:
Need to revisit folder structure sometime.
Everything is in one file rn because assignment was small enough.
*/
