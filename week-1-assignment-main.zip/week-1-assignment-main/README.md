assignment 1

Simple react based assignment project using plain React.createElement syntax.

Files included:
- index.html
- app.js
- styles.css

Notes:
- All tasks are rendered on the same page
- Date and time updates every second
- Greeting button switches between english and spanish
- Product and user sections are component based

Open the index.html file in browser to run the project.


Built mostly for practice and assignment submission.
